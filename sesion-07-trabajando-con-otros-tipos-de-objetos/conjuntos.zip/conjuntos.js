//Ejercicio 1 - Módulo 7

const familia = ["Cristina", "Federico", "Nicolas", "Lihuel"];
const miFamilia = new Set(familia);
console.log(miFamilia);

miFamilia.add("Lihuel");
console.log(miFamilia);


miFamilia.add("Javascript");
console.log(miFamilia);